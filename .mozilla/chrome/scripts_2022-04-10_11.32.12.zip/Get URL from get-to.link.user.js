// ==UserScript==
// @name        Get URL from get-to.link
// @namespace   Violentmonkey Scripts
// @match       https://get-to.link/*
// @grant       GM_setClipboard
// @version     1.0
// @author      mustaqimM
// @description 2022/04/10, 10:25:11
// ==/UserScript==

(function() {
  'use strict';
  
  var url = "https://psa.pm/torrents/";
  var icon = "file:///usr/share/icons/Papirus/22x22/actions/edit-link.svg"
  
  GM_setClipboard(document.querySelector('a[href*=' + CSS.escape(url) + ']'), 'text/plain');
  
  // OPTIONAL: Show system notification, comment block if unneeded.
  if (Notification.permission === 'granted') {
    var notify = new Notification('Copied URL!', {
      body: 'Copied url to clipboard',
      icon: icon
    });
  } else {
    Notification.requestPermission().then(function(status) {
      if(status === 'granted') {
        var notify = new Notification('Copied URL!', {
          body: 'Copied url to clipboard',
          icon: icon
        });

      } else {
        console.log('User denied the notification permission dialogue.');
      }
    }).catch(function(err) {
      console.error(err);
    });
  }
  
})();